﻿
Partial Class Main_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

