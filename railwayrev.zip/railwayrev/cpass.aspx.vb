
Partial Class cpass
    Inherits System.Web.UI.Page


End Class
