
Partial Class confirmbooking
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.trainno.Text = Session("tr")
        Me.trj.Text = Session("dat")
        Me.station.Text = Session("sta")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Response.Redirect("booking.aspx")
    End Sub
End Class
