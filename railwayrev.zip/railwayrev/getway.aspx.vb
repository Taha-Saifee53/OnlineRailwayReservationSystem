
Partial Class getway
    Inherits System.Web.UI.Page

    Protected Sub nm_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles nm.TextChanged

    End Sub

    Protected Sub st_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles st.TextChanged

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.order.Text = "DJKNT12654478899"
    End Sub
End Class
