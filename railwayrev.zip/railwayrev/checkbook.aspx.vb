
Partial Class checkbook
    Inherits System.Web.UI.Page
    Dim cnt, i As Integer
    Dim ob As New Class1
    Protected Sub book_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles book.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from train"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        For i = 0 To cnt - 1
            If Me.stran.Text = ob.ds.Tables("lg").Rows(i)(5) And Me.dtran.Text = ob.ds.Tables("lg").Rows(i)(6) And Me.trj.Text <> "" Then
                Session("sst") = Me.stran.Text
                Session("dst") = Me.dtran.Text
                Session("dat") = Me.trj.Text
                Response.Redirect("traininfo.aspx")
            End If
        Next
        Me.Label1.Visible = True
        


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
