
Partial Class registration
    Inherits System.Web.UI.Page
    Dim i As Integer
    Dim ob As New Class1
    Dim dob, ma, gen, occu, scq As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        For i = 1 To 31
            Me.dd.Items.Add(i)
        Next
        For i = 1 To 12
            Me.mm.Items.Add(i)
        Next
        For i = 1990 To 2016
            Me.yy.Items.Add(i)
        Next
    End Sub

    
    Protected Sub submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles submit.Click
        dob = Me.dd.SelectedItem.ToString & "/" & Me.mm.SelectedItem.ToString & "/" & Me.yy.SelectedItem.ToString
        ma = Me.marital.SelectedItem.ToString
        occu = Me.occ.SelectedItem.ToString
        gen = Me.gender.SelectedItem.ToString
        scq = Me.sc.SelectedItem.ToString
        ob.cmd.Connection = ob.con
        ob.con.Open()
        ob.cmd.CommandText = "insert into reg values('" & Me.nm.Text & "','" & Me.lm.Text & "','" & gen & "','" & ma & "','" & dob & "','" & occu & "','" & Me.adh.Text & "','" & Me.email.Text & "','" & Me.pass.Text & "','" & Me.num.Text & "','" & Me.ad.Text & "','" & Me.stnum.Text & "','" & Me.city.Text & "','" & scq & "','" & Me.sca.Text & "')"
        ob.cmd.ExecuteNonQuery()
        ob.con.Close()

    End Sub
End Class
