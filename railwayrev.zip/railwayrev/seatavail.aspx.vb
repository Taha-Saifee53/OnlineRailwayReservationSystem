
Partial Class seatavail
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim i, cnt As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub se_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles se.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from train"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        For i = 0 To cnt - 1
            If Me.trainn.Text = ob.ds.Tables("lg").Rows(i)(0) And Me.st.Text = ob.ds.Tables("lg").Rows(i)(5) And Me.jd.Text <> "" And Me.cla.Text <> "Select" And Me.dt.Text = ob.ds.Tables("lg").Rows(i)(6) Then
                Session("no") = Me.trainn.Text
                Session("date") = Me.jd.Text
                Response.Redirect("seatenquiry.aspx")
            End If
        Next
        Me.err.Visible = True
    End Sub
End Class
