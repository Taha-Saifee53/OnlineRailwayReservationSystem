
Partial Class traindetails
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.ori.Text = Session("st")
        Me.des.Text = Session("dt")
        Me.cla.Text = Session("cla")
    End Sub
End Class
