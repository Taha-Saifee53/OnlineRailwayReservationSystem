
Partial Class login
    Inherits System.Web.UI.Page

    Protected Sub lbutton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbutton.Click
        Session("t") = Me.email.Text
        Response.Redirect("welcome.aspx")
    End Sub
End Class
