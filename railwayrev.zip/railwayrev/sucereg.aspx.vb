Imports System.Net.Mail
Partial Class sucereg
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Dim smpt As New SmtpClient
            Dim mm As MailMessage = New MailMessage()
            smpt.UseDefaultCredentials = False
            smpt.Credentials = New Net.NetworkCredential("username@gmail.com", "password")
            smpt.Port = 49164
            smpt.EnableSsl = True
            smpt.Host = "smpt.gmail.com"
            mm.From = New MailAddress("tahakasimsaifee53@gmail.com")
            mm.Subject = "hello"
            mm.Body = "first mail"
            mm.IsBodyHtml = True
            mm.To.Add("tahakasimsaifee53@gmail.com")
            smpt.Send(mm)
            MsgBox("Mail Sent")


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
       
    End Sub
End Class
