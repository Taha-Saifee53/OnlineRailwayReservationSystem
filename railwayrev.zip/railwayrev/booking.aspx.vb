Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data.SqlClient

Partial Class booking
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.trainno.Text = Session("tr1") & "/" & Session("tr2")
        Me.trj.Text = Session("dat")
        Me.station.Text = Session("tr3")
        Me.tstation.Text = Session("tr2")
        Me.bstation.Items.Add("Howrah")
        Me.rstation.Text = Session("tr4")
        Me.clas.Text = Session("cla")
        Me.quota.Text = "General"
    End Sub

    Protected Sub trainno_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles trainno.TextChanged

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Session("tr") = Me.trainno.Text
        Session("dat") = Me.trj.Text
        Session("sta") = Me.station.Text
        Response.Redirect("confirmbooking.aspx")
    End Sub
End Class
