
Partial Class pnrstatus
    Inherits System.Web.UI.Page

End Class
