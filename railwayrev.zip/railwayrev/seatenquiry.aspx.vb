
Partial Class seatenquiry
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim cnt As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.dat.Text = Session("date")
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from seat"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        Me.scount.Text = "Available" & " " & cnt
        Me.acount.Text = "Available" & " " & cnt
    End Sub
End Class
