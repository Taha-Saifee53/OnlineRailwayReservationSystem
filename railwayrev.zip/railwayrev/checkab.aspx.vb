
Partial Class checkab
    Inherits System.Web.UI.Page

    Dim da As Date
    Dim dtfi As New DateFormat
    Dim ob As New Class1
    Dim cnt, i As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.cl1.Text = Session("tra1")

        Me.trannd.Text = Session("train1") & "/" & Session("train2")
        If Me.cl1.Text = "3A AC" Then
            Me.da1.Text = Session("dat1")
            da = Convert.ToDateTime(Me.da1.Text)
            Me.da2.Text = da.AddDays(1)
            Me.da3.Text = da.AddDays(2)
            Me.da4.Text = da.AddDays(3)
            Me.da5.Text = da.AddDays(4)
            Me.da6.Text = da.AddDays(5)
            Session("tran1") = Session("train1")
            Session("tran2") = Session("train2")
            Session("tran3") = Session("train3")
            Session("tran4") = Session("train4")
            ob.cmd.Connection = ob.con
            ob.cmd.CommandText = "select * from seat"
            ob.adp.SelectCommand = ob.cmd
            ob.adp.Fill(ob.ds, "lg")
            cnt = ob.ds.Tables("lg").Rows.Count
            Me.a1.Text = "Available" & " " & cnt
            Me.a2.Text = "Available" & " " & cnt
            Me.a3.Text = "Available" & " " & cnt
            Me.a4.Text = "Available" & " " & cnt
            Me.a5.Text = "Available" & " " & cnt
            Me.a6.Text = "Available" & " " & cnt
            Me.f1.Text = "1200"
            Me.f2.Text = "50"
            Me.f3.Text = "1250"
        ElseIf Me.cl1.Text = "SLEEPER" Then
            Me.da1.Text = Session("dat1")
            da = Convert.ToDateTime(Me.da1.Text)
            Me.da2.Text = da.AddDays(1)
            Me.da3.Text = da.AddDays(2)
            Me.da4.Text = da.AddDays(3)
            Me.da5.Text = da.AddDays(4)
            Me.da6.Text = da.AddDays(5)
            Session("tran1") = Session("train1")
            Session("tran2") = Session("train2")
            Session("tran3") = Session("train3")
            Session("tran4") = Session("train4")
            ob.cmd.Connection = ob.con
            ob.cmd.CommandText = "select * from seat"
            ob.adp.SelectCommand = ob.cmd
            ob.adp.Fill(ob.ds, "lg")
            cnt = ob.ds.Tables("lg").Rows.Count
            Me.a1.Text = "Available" & " " & cnt
            Me.a2.Text = "Available" & " " & cnt
            Me.a3.Text = "Available" & " " & cnt
            Me.a4.Text = "Available" & " " & cnt
            Me.a5.Text = "Available" & " " & cnt
            Me.a6.Text = "Available" & " " & cnt
            Me.f1.Text = "700"
            Me.f2.Text = "50"
            Me.f3.Text = "750"
        End If

        ' Me.ch1.Text = Session("tra1")
        'Me.ch2.Text = Session("tra4")
        'Me.Label1.Text = Session("tra3")

        'Me.da1.Text = Session("dat1")
        'da = Convert.ToDateTime(Me.da1.Text)
        'Me.Label2.Text = da.AddDays(1)
    End Sub

    Protected Sub book1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles book1.Click
        Session("dat") = Me.da1.Text
        Session("tr1") = Session("tran1")
        Session("tr2") = Session("tran2")
        Session("tr3") = Session("tran3")
        Session("tr4") = Session("tran4")
        Session("cla") = Me.cl1.Text
        Response.Redirect("booking.aspx")

    End Sub

    Protected Sub bac_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bac.Click
        Response.Redirect("traininfo.aspx")
    End Sub
End Class
