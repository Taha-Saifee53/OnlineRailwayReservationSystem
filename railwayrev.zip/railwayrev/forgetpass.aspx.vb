
Partial Class forgetpass
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim cnt, i As Integer
    Protected Sub check_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles check.Click
        If Session("randomStr").ToString() = txtcaptcha.Text Then
            ob.cmd.Connection = ob.con
            ob.cmd.CommandText = "select *from reg"
            ob.adp.SelectCommand = ob.cmd
            ob.adp.Fill(ob.ds, "tg")
            cnt = ob.ds.Tables("tg").Rows.Count
            For i = 0 To cnt - 1
                If Me.emf.Text = ob.ds.Tables("tg").Rows(i)(7) Then
                    Session("email") = ob.ds.Tables("tg").Rows(i)(7)
                    Session("scq") = ob.ds.Tables("tg").Rows(i)(13)
                    Response.Redirect("rpass.aspx")
                End If
            Next
            Me.err.Visible = True
            Me.err.Text = "Please Enter Correct Email ID"
        Else
            Me.err.Visible = True
            Me.err.Text = "Wrong text inserted,Please enter new characters shown in image textbox"
        End If

    End Sub
End Class
