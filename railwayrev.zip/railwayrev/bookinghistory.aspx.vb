
Partial Class bookinghistory
    Inherits System.Web.UI.Page

End Class
