
Partial Class adminlogin
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim i, cnt As Integer
    Protected Sub but_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles but.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from admin"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        For i = 0 To cnt - 1
            If Me.adn.Text = ob.ds.Tables("lg").Rows(i)(0) And Me.pass.Text = ob.ds.Tables("lg").Rows(i)(1) Then
                Response.Redirect("adminhome.aspx")
            End If
        Next
        Me.Label2.Visible = True
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
