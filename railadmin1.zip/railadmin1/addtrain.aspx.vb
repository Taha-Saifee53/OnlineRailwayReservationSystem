
Partial Class addtrain
    Inherits System.Web.UI.Page
    Dim i As Integer
    Dim ob As New Class1
    Dim ar, dp As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.art.Items.Add("00")
        Me.art.Items.Add("01")
        Me.art.Items.Add("02")
        Me.art.Items.Add("03")
        Me.art.Items.Add("04")
        Me.art.Items.Add("05")
        Me.art.Items.Add("06")
        Me.art.Items.Add("07")
        Me.art.Items.Add("08")
        Me.art.Items.Add("09")
        For i = 10 To 23
            Me.art.Items.Add(i)
        Next
        Me.art1.Items.Add("00")
        Me.art1.Items.Add("01")
        Me.art1.Items.Add("02")
        Me.art1.Items.Add("03")
        Me.art1.Items.Add("04")
        Me.art1.Items.Add("05")
        Me.art1.Items.Add("06")
        Me.art1.Items.Add("07")
        Me.art1.Items.Add("08")
        Me.art1.Items.Add("09")
        For i = 10 To 59
            Me.art1.Items.Add(i)
        Next
        Me.dep.Items.Add("00")
        Me.dep.Items.Add("01")
        Me.dep.Items.Add("02")
        Me.dep.Items.Add("03")
        Me.dep.Items.Add("04")
        Me.dep.Items.Add("05")
        Me.dep.Items.Add("06")
        Me.dep.Items.Add("07")
        Me.dep.Items.Add("08")
        Me.dep.Items.Add("09")
        For i = 10 To 23
            Me.dep.Items.Add(i)
        Next
        Me.dep1.Items.Add("00")
        Me.dep1.Items.Add("01")
        Me.dep1.Items.Add("02")
        Me.dep1.Items.Add("03")
        Me.dep1.Items.Add("04")
        Me.dep1.Items.Add("05")
        Me.dep1.Items.Add("06")
        Me.dep1.Items.Add("07")
        Me.dep1.Items.Add("08")
        Me.dep1.Items.Add("09")
        For i = 10 To 59
            Me.dep1.Items.Add(i)
        Next

    End Sub

    Protected Sub add_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles add.Click
        ar = Me.art.SelectedItem.ToString & ":" & Me.art1.SelectedItem.ToString
        dp = Me.dep.SelectedItem.ToString & ":" & Me.dep1.SelectedItem.ToString
        ob.con.Open()
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "insert into traindet values('" & Me.trannam.Text & "','" & Me.trann.Text & "','" & Me.sst.Text & "','" & Me.dst.Text & "','" & ar & "','" & dp & "','" & Me.scf.Text & "','" & Me.otb.Text & "','" & Me.af.Text & "','" & Me.s1.Text & "','" & Me.s2.Text & "','" & Me.s3.Text & "','" & Me.s4.Text & "','" & Me.s5.Text & "')"
        ob.cmd.ExecuteNonQuery()
        ob.con.Close()
        MsgBox("Train Details Successfully added in the database")
    End Sub
End Class
