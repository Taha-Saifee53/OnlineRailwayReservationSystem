
Partial Class ticketreport
    Inherits System.Web.UI.Page

End Class
