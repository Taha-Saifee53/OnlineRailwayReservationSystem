
Partial Class traindetail
    Inherits System.Web.UI.Page

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Session("t") = Me.GridView1.SelectedRow.Cells(0).Text
        Session("t1") = Me.GridView1.SelectedRow.Cells(1).Text
        Session("t2") = Me.GridView1.SelectedRow.Cells(2).Text
        Session("t3") = Me.GridView1.SelectedRow.Cells(3).Text
        Session("t4") = Me.GridView1.SelectedRow.Cells(4).Text
        Session("t5") = Me.GridView1.SelectedRow.Cells(5).Text
        Session("t6") = Me.GridView1.SelectedRow.Cells(6).Text
        Session("t7") = Me.GridView1.SelectedRow.Cells(7).Text
        Session("t8") = Me.GridView1.SelectedRow.Cells(8).Text
        Session("t9") = Me.GridView1.SelectedRow.Cells(9).Text
        Session("t10") = Me.GridView1.SelectedRow.Cells(10).Text
        Session("t11") = Me.GridView1.SelectedRow.Cells(11).Text
        Session("t12") = Me.GridView1.SelectedRow.Cells(12).Text
        Session("t13") = Me.GridView1.SelectedRow.Cells(13).Text
        Session("t14") = Me.GridView1.SelectedRow.Cells(14).Text
        Response.Redirect("update.aspx")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
