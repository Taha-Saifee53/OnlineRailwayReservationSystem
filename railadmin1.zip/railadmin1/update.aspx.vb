
Partial Class update
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim ar, dp As String
    Dim i As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Me.trannam.Text = Session("t1")
            Me.trann.Text = Session("t")
            Me.sst.Text = Session("t2")
            Me.dst.Text = Session("t3")
            Me.art.Text = Session("t4")
            Me.dep.Text = Session("t5")
            Me.otb.Text = Session("t7")
            Me.scf.Text = Session("t6")
            Me.af.Text = Session("t8")
            Me.s1.Text = Session("t9")
            Me.s2.Text = Session("t10")
            Me.s3.Text = Session("t11")
            Me.s4.Text = Session("t12")
            Me.s5.Text = Session("t13")

        End If
    End Sub

    Protected Sub add_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles add.Click
        ob.cmd.Connection = ob.con
        ob.con.Open()
        ob.cmd.CommandText = "update traindet set trainname='" & Me.trannam.Text & "',tnum='" & Me.trann.Text & "',source='" & Me.sst.Text & "',desti='" & Me.dst.Text & "',arrtime='" & Me.art.Text & "',deptime='" & Me.dep.Text & "',sfare='" & Me.scf.Text & "',otb='" & Me.otb.Text & "',afare='" & Me.af.Text & "',s1='" & Me.s1.Text & "',s2='" & Me.s2.Text & "',s3='" & Me.s3.Text & "',s4='" & Me.s4.Text & "',s5='" & Me.s5.Text & "' where tnum='" & Me.trann.Text & "'"
        ob.cmd.ExecuteNonQuery()
        ob.con.Close()
        MsgBox("Successfully updated the database")
    End Sub
End Class
