
Partial Class viewuser
    Inherits System.Web.UI.Page

End Class
