
Partial Class addtrain
    Inherits System.Web.UI.Page
    Dim i As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.art.Items.Add("00")
        Me.art.Items.Add("01")
        Me.art.Items.Add("02")
        Me.art.Items.Add("03")
        Me.art.Items.Add("04")
        Me.art.Items.Add("05")
        Me.art.Items.Add("06")
        Me.art.Items.Add("07")
        Me.art.Items.Add("08")
        Me.art.Items.Add("09")
        For i = 10 To 23
            Me.art.Items.Add(i)
        Next
        Me.art1.Items.Add("00")
        Me.art1.Items.Add("01")
        Me.art1.Items.Add("02")
        Me.art1.Items.Add("03")
        Me.art1.Items.Add("04")
        Me.art1.Items.Add("05")
        Me.art1.Items.Add("06")
        Me.art1.Items.Add("07")
        Me.art1.Items.Add("08")
        Me.art1.Items.Add("09")
        For i = 10 To 59
            Me.art1.Items.Add(i)
        Next
    End Sub
End Class
