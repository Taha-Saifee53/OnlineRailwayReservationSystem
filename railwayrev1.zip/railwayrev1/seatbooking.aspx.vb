
Partial Class seatbooking
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim i, cnt As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim curr As Date = DateTime.Now.ToString
            Dim last As Date = DateTime.Now.ToString
            Me.Label2.Text = curr
            Me.Label3.Text = last.AddMonths(4).ToString

        End If
        

    End Sub

    Protected Sub book_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles book.Click


        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from train"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        For i = 0 To cnt - 1
            If Me.Label2.Text < Me.trj.Text And Me.Label3.Text > Me.trj.Text And Me.tran.Text = ob.ds.Tables("lg").Rows(i)(0) And Me.trann.Text = ob.ds.Tables("lg").Rows(i)(1) And Me.stran.Text = ob.ds.Tables("lg").Rows(i)(5) And Me.dtran.Text = ob.ds.Tables("lg").Rows(i)(6) And Me.trj.Text <> "" Then
                Session("trainno") = Me.tran.Text
                Session("trainna") = Me.trann.Text
                Session("st") = Me.stran.Text
                Session("dt") = Me.dtran.Text
                Session("cl") = Me.clas.Text
                Session("quo") = Me.quota.Text
                Session("date") = Me.trj.Text
                Response.Redirect("booking.aspx")
            End If
        Next
        Me.Label1.Visible = True
    End Sub

    Protected Sub cl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cl.Click
        Me.tran.Text = ""
        Me.trann.Text = ""
        Me.stran.Text = ""
        Me.dtran.Text = ""
        Me.clas.SelectedValue = 0
        Me.quota.SelectedValue = 0
        Me.trj.Text = ""
    End Sub
End Class
