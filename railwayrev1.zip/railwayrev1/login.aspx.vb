
Partial Class login
    Inherits System.Web.UI.Page
    Dim cnt, i As Integer
    Dim ob As New Class1

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub

    Protected Sub lbutton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbutton.Click
        ob.con.Open()
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from reg"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        For i = 0 To cnt - 1
            If Session("randomStr").ToString = Me.txtcaptcha.Text Then
                If Me.email.Text = ob.ds.Tables("lg").Rows(i)(7) And Me.pass.Text = ob.ds.Tables("lg").Rows(i)(8) Then
                    Session("name") = ob.ds.Tables("lg").Rows(i)(0) & " " & ob.ds.Tables("lg").Rows(i)(1)
                    Response.Redirect("welcome1.aspx")
                Else
                    Me.inco.Visible = True
                    Me.inco.Text = "Password or Email Id is Incorrect"
                End If
            Else
                Me.inco.Visible = True
                Me.inco.Text = "Wrong text inserted,Please enter new characters shown in image textbox"
            End If
        Next
    End Sub
End Class
