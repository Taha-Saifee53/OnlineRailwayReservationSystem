
Partial Class cancelt
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim cnt, cnt1, i, j, cas, amt2 As Integer
    Dim amt1, pnn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.pnr.Text = Session("pn1")
        Me.trn.Text = Session("tr")
        Me.dt.Text = Session("dt")
        Me.fs.Text = Session("fs")
        Me.ts.Text = Session("ts")
        Me.bs.Text = Session("bos")
        Me.rs.Text = Session("rs")
        Me.cl.Text = Session("cs")
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from pay"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "py")
        cnt1 = ob.ds.Tables("py").Rows.Count
        For j = 0 To cnt1 - 1
            If Me.pnr.Text = ob.ds.Tables("py").Rows(j)(1) Then
                Me.tid.Text = ob.ds.Tables("py").Rows(j)(0)
                Me.amt.Text = ob.ds.Tables("py").Rows(j)(12)
                amt1 = Me.amt.Text
                amt2 = CType(amt1, Integer)
                cas = amt2 - CType(amt1, Integer) * 0.1
                Me.cash.Text = cas.ToString
            End If
        Next
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        pnn = Session("pn1")
        ob.cmd.Connection = ob.con
        ob.con.Open()
        ob.cmd.CommandText = "delete from booking where pnr='" & pnn & "'"
        ob.cmd.ExecuteNonQuery()
        ob.con.Close()
        Response.Redirect("logout.aspx")
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("welcome1.aspx")
    End Sub
End Class
