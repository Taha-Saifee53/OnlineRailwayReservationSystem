
Partial Class registration
    Inherits System.Web.UI.Page

    Dim cnt, i As Integer
    Dim ob As New Class1

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim i As Integer
        For i = 1 To 31
            Me.dd.Items.Add(i)
        Next
        For i = 1 To 12
            Me.mm.Items.Add(i)
        Next
        For i = 1947 To 2000
            Me.yy.Items.Add(i)
        Next
    End Sub

    
    Protected Sub submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles submit.Click
        Dim dob, gen, mar, occ, seq As String
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from reg"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "qw")
        cnt = ob.ds.Tables("qw").Rows.Count
        For i = 0 To cnt - 1

            If Session("randomStr").ToString() = txtcaptcha.Text Then
                If Me.email.Text = ob.ds.Tables("qw").Rows(i)(7) Then
                    Response.Redirect("regerror.aspx")
                Else
                    dob = Me.dd.SelectedItem.ToString & "/" & Me.mm.SelectedItem.ToString & "/" & Me.yy.SelectedItem.ToString
                    gen = Me.gender.SelectedItem.ToString
                    mar = Me.marital.SelectedItem.ToString
                    occ = Me.occ.SelectedItem.ToString
                    seq = Me.sc.SelectedItem.ToString
                    ob.cmd.Connection = ob.con
                    ob.con.Open()
                    ob.cmd.CommandText = "insert into reg values('" & Me.nm.Text & "','" & Me.lm.Text & "','" & gen & "','" & mar & "','" & dob & "','" & occ & "','" & Me.adh.Text & "','" & Me.email.Text & "','" & Me.pass.Text & "','" & Me.num.Text & "','" & Me.ad.Text & "','" & Me.stnum.Text & "','" & Me.city.Text & "','" & Me.sca.Text & "','" & seq & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.con.Close()
                    Response.Redirect("sucereg.aspx")
                End If

            Else
                Me.Label2.Text = "Wrong text inserted,Please enter new characters shown in image textbox"
            End If
        Next
    End Sub

    
   

   
End Class
