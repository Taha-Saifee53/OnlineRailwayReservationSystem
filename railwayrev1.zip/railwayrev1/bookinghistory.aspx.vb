
Partial Class bookinghistory
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim cnt, i As Integer

    Protected Sub his_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles his.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from pay"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "dln")
        cnt = ob.ds.Tables("dln").Rows.Count
        For i = 0 To cnt - 1
            If Session("randomStr").ToString() = txtcaptcha.Text Then
                If Me.pn.Text = ob.ds.Tables("dln").Rows(i)(7) Then
                    Session("tib") = Me.pn.Text
                    Response.Redirect("displayhistory.aspx")
                Else
                    Me.err.Visible = True
                    Me.err.Text = "Please enter Correct email id"
                End If
            Else
                Me.err.Visible = True
                Me.err.Text = "Please enter correct captcha code"
            End If
        Next
    End Sub

    Protected Sub cl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cl.Click
        If Me.Label1.Text = "" Then
            Response.Redirect("welcome.aspx")
        Else
            Response.Redirect("welcome1.aspx")
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Label1.Text = Session("we")
    End Sub
End Class
