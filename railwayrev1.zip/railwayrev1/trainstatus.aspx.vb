
Partial Class trainstatus
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim i, cnt As Integer

   Protected Sub getd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles getd.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from traindet"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        For i = 0 To cnt - 1
            If Me.ss.Text = ob.ds.Tables("lg").Rows(i)(2) And Me.dd.Text = ob.ds.Tables("lg").Rows(i)(3) And Me.jd.Text <> "" And Me.cl.Text <> "Select" And Me.ss.Text <> Me.dd.Text Then
                Session("st") = Me.ss.Text
                Session("dt") = Me.dd.Text
                Session("trj") = Me.jd.Text
                Session("cla") = Me.cl.Text
                Session("we") = Me.Label2.Text
                Response.Redirect("traindetails.aspx")
            End If
        Next
        Me.Label1.Visible = True
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Me.Label2.Text = "" Then
            Response.Redirect("welcome.aspx")
        Else
            Response.Redirect("welcome1.aspx")
        End If


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Label2.Text = Session("we")
    End Sub
End Class
