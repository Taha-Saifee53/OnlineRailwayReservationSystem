
Partial Class ticketcancel
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim i, cnt As Integer
    Dim pnrn As String

    Protected Sub bup_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bup.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from booking"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "nan")
        cnt = ob.ds.Tables("nan").Rows.Count
        For i = 0 To cnt - 1
            If Session("randomStr").ToString() = txtcaptcha.Text Then
                If Me.txt1.Text = ob.ds.Tables("nan").Rows(i)(0) Then
                    Session("pn") = Me.txt1.Text
                    Response.Redirect("cncl.aspx?")
                Else
                    Me.inco.Visible = True
                End If
            Else
                Me.Label2.Text = "Wrong text inserted,Please enter new characters shown in image textbox"
            End If
        Next
    End Sub

    Protected Sub bac_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bac.Click
        Response.Redirect("welcome1.aspx")
    End Sub
End Class
