
Partial Class rpass
    Inherits System.Web.UI.Page
    Dim cnt, i As Integer
    Dim ob As New Class1
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.ema.Text = Session("email")
        Me.ques.Text = Session("scq")
    End Sub

    Protected Sub submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles submit.Click
        If Session("randomStr").ToString() = txtcaptcha.Text Then
            ob.cmd.Connection = ob.con
            ob.cmd.CommandText = "select *from reg"
            ob.adp.SelectCommand = ob.cmd
            ob.adp.Fill(ob.ds, "tib")
            cnt = ob.ds.Tables("tib").Rows.Count
            For i = 0 To cnt - 1
                If Me.ans.Text = ob.ds.Tables("tib").Rows(i)(13) And Me.ques.Text = ob.ds.Tables("tib").Rows(i)(14) Then
                    ob.cmd.Connection = ob.con
                    ob.con.Open()
                    ob.cmd.CommandText = "UPDATE reg SET pass = '" & Me.npas.Text & "' WHERE email='" & Me.ema.Text & "'"
                    ob.cmd.ExecuteNonQuery()
                    ob.con.Close()
                    Response.Redirect("cpass.aspx")
                End If
            Next
            Me.err.Visible = True
            Me.err.Text = "Please Correct Security Answer"

        Else
            Me.err.Visible = True
            Me.err.Text = "Wrong text inserted,Please enter new characters shown in image textbox"
        End If
    End Sub
End Class
