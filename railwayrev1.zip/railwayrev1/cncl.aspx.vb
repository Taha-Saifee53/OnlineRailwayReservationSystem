
Partial Class cncl
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim i, cnt As Integer
    Dim pnr, se, be, co, seat As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pnr = Session("pn")

        ob.cmd.Connection = ob.con
        ob.con.Open()
        ob.cmd.CommandText = "select *from booking"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "dh")
        cnt = ob.ds.Tables("dh").Rows.Count
        For i = 0 To cnt - 1
            If pnr = ob.ds.Tables("dh").Rows(i)(0) Then
                Me.trainno.Text = ob.ds.Tables("dh").Rows(i)(9)
                Me.trj.Text = ob.ds.Tables("dh").Rows(i)(12)
                Me.station.Text = ob.ds.Tables("dh").Rows(i)(10)
                Me.tstation.Text = ob.ds.Tables("dh").Rows(i)(11)
                Me.bstation.Text = ob.ds.Tables("dh").Rows(i)(14)
                Me.rstation.Text = ob.ds.Tables("dh").Rows(i)(15)
                Me.cls.Text = ob.ds.Tables("dh").Rows(i)(13)
                se = ob.ds.Tables("dh").Rows(i)(7)
                If Me.p1.Text = "" And se <> "" Then
                    Me.p1.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.a1.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.gen1.Text = ob.ds.Tables("dh").Rows(i)(3)
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b1.Text = co & "\" & be & "\" & seat
                    Me.sn1.Text = ob.ds.Tables("dh").Rows(i)(4)
                ElseIf Me.p2.Text = "" And se <> "" Then
                    Me.p2.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.a2.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.gen2.Text = ob.ds.Tables("dh").Rows(i)(3)
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b2.Text = co & "\" & be & "\" & seat
                    Me.sn2.Text = ob.ds.Tables("dh").Rows(i)(4)
                ElseIf Me.p3.Text = "" And se <> "" Then
                    Me.p3.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.a3.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.gen3.Text = ob.ds.Tables("dh").Rows(i)(3)
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b3.Text = co & "\" & be & "\" & seat
                    Me.sn3.Text = ob.ds.Tables("dh").Rows(i)(4)
                ElseIf Me.p4.Text = "" And se <> "" Then
                    Me.p4.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.a4.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.gen4.Text = ob.ds.Tables("dh").Rows(i)(3)
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b4.Text = co & "\" & be & "\" & seat
                    Me.sn4.Text = ob.ds.Tables("dh").Rows(i)(4)
                ElseIf Me.p5.Text = "" And se <> "" Then
                    Me.p5.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.a5.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.gen5.Text = ob.ds.Tables("dh").Rows(i)(3)
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b5.Text = co & "\" & be & "\" & seat
                    Me.sn5.Text = ob.ds.Tables("dh").Rows(i)(4)
                ElseIf Me.p6.Text = "" And se <> "" Then
                    Me.p6.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.a6.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.gen6.Text = ob.ds.Tables("dh").Rows(i)(3)
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b6.Text = co & "\" & be & "\" & seat
                    Me.sn6.Text = ob.ds.Tables("dh").Rows(i)(4)
                ElseIf Me.ch1.Text = "" And se = "" Then
                    Me.ch1.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.ag1.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.g1.Text = ob.ds.Tables("dh").Rows(i)(3)
                ElseIf Me.ch2.Text = "" And se = "" Then
                    Me.ch2.Text = ob.ds.Tables("dh").Rows(i)(1)
                    Me.ag2.Text = ob.ds.Tables("dh").Rows(i)(2)
                    Me.g2.Text = ob.ds.Tables("dh").Rows(i)(3)
                End If
            End If

        Next
        ob.con.Close()
    End Sub

    Protected Sub su_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles su.Click
        pnr = Session("pn")
        ob.cmd.Connection = ob.con
        ob.con.Open()
        ob.cmd.CommandText = "select *from booking"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "dh")
        cnt = ob.ds.Tables("dh").Rows.Count
        For i = 0 To cnt - 1
            If pnr = ob.ds.Tables("dh").Rows(i)(0) Then
                se = ob.ds.Tables("dh").Rows(i)(7)
                If Me.p1.Text = "" And se <> "" Then
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b1.Text = co & "\" & be & "\" & seat
                    ob.cmd.CommandText = "insert into seat values('" & co & "','" & seat & "','" & be & "')"
                    ob.cmd.ExecuteNonQuery()
                    Me.sn1.Text = ob.ds.Tables("dh").Rows(i)(4)
                ElseIf Me.p2.Text = "" And se <> "" Then
                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b1.Text = co & "\" & be & "\" & seat
                    ob.cmd.CommandText = "insert into seat values('" & co & "','" & seat & "','" & be & "')"
                    ob.cmd.ExecuteNonQuery()
                    Me.sn2.Text = ob.ds.Tables("dh").Rows(i)(4)

                ElseIf Me.p3.Text = "" And se <> "" Then

                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b1.Text = co & "\" & be & "\" & seat
                    ob.cmd.CommandText = "insert into seat values('" & co & "','" & seat & "','" & be & "')"
                    ob.cmd.ExecuteNonQuery()
                    Me.sn3.Text = ob.ds.Tables("dh").Rows(i)(4)

                ElseIf Me.p4.Text = "" And se <> "" Then

                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b1.Text = co & "\" & be & "\" & seat
                    ob.cmd.CommandText = "insert into seat values('" & co & "','" & seat & "','" & be & "')"
                    ob.cmd.ExecuteNonQuery()
                    Me.sn4.Text = ob.ds.Tables("dh").Rows(i)(4)

                ElseIf Me.p5.Text = "" And se <> "" Then

                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b1.Text = co & "\" & be & "\" & seat
                    ob.cmd.CommandText = "insert into seat values('" & co & "','" & seat & "','" & be & "')"
                    ob.cmd.ExecuteNonQuery()
                    Me.sn5.Text = ob.ds.Tables("dh").Rows(i)(4)

                ElseIf Me.p6.Text = "" And se <> "" Then

                    co = ob.ds.Tables("dh").Rows(i)(8)
                    be = ob.ds.Tables("dh").Rows(i)(5)
                    seat = ob.ds.Tables("dh").Rows(i)(7)
                    Me.b1.Text = co & "\" & be & "\" & seat
                    ob.cmd.CommandText = "insert into seat values('" & co & "','" & seat & "','" & be & "')"
                    ob.cmd.ExecuteNonQuery()
                    Me.sn6.Text = ob.ds.Tables("dh").Rows(i)(4)
                End If
            End If
        Next
        ob.con.Close()
        Session("pn1") = pnr
        Session("tr") = Me.trainno.Text
        Session("dt") = Me.trj.Text
        Session("bos") = Me.bstation.Text
        Session("ts") = Me.tstation.Text
        Session("fs") = Me.station.Text
        Session("rs") = Me.rstation.Text
        Session("cs") = Me.cls.Text
        Response.Redirect("cancelt.aspx")
    End Sub
End Class
