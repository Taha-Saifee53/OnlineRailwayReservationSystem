
Partial Class regerror
    Inherits System.Web.UI.Page

End Class
