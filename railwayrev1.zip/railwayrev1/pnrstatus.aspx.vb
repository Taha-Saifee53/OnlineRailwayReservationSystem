
Partial Class pnrstatus
    Inherits System.Web.UI.Page
    Dim cnt, i As Integer
    Dim ob As New Class1

    Protected Sub pnrl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles pnrl.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from booking"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "tic")
        cnt = ob.ds.Tables("tic").Rows.Count
        For i = 0 To cnt - 1
            If Session("randomStr").ToString() = txtcaptcha.Text Then
                If Me.pnr.Text = ob.ds.Tables("tic").Rows(i)(0) Then
                    Session("pnrs") = Me.pnr.Text
                    Session("we") = Me.Label2.Text
                    Response.Redirect("pnrview.aspx")
                Else
                    Me.err.Visible = True
                    Me.err.Text = "Please Enter Correct PNR Number"
                End If
            Else
                Me.err.Visible = True
                Me.err.Text = "Please enter correct captcha image"
            End If

        Next
    End Sub

    Protected Sub bac_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bac.Click
        If Me.Label2.Text = "" Then
            Response.Redirect("welcome.aspx")
        Else
            Response.Redirect("welcome1.aspx")
        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Label2.Text = Session("we")
    End Sub
End Class
