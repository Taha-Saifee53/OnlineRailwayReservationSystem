
Partial Class getway
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim cnt, i As Integer
    Dim ex, ba, ode As String
    Dim curr As Date

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Session("pnrs") = Session("pnrst")
        Me.amt.Text = Session("amnt")
        ob.con.Open()
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from pay"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        ode = "DJKNT50467398" & cnt + 1
        Me.order.Text = ode
        For i = 1 To 12
            Me.dd.Items.Add(i)

        Next
        For i = 2000 To 2050
            Me.mon.Items.Add(i)
        Next
        ob.con.Close()
        
    End Sub

    Protected Sub pay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles pay.Click
        ba = Me.drop.SelectedItem.ToString
        ex = Me.dd.SelectedItem.ToString & "/" & Me.mon.SelectedItem.ToString
        curr = Date.Today.ToString
        ob.con.Open()
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "insert into pay values('" & Me.order.Text & "','" & Session("pnrs") & "','" & Me.nm.Text & "','" & Me.ad.Text & "','" & Me.pin.Text & "','" & Me.ph.Text & "','" & Me.st.Text & "','" & Me.em.Text & "','" & ba & "','" & Me.card.Text & "','" & ex & "','" & Me.cc.Text & "','" & Me.amt.Text & "','" & curr & "')"
        ob.cmd.ExecuteNonQuery()
        ob.con.Close()
        Session("pnn") = Session("pnrs")
        Session("od") = ode
        Session("amt") = Me.amt.Text
        Response.Redirect("genticket.aspx")
    End Sub
End Class
