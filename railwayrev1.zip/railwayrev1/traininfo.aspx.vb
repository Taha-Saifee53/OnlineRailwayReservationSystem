Imports System.Data
Imports System.Text
Imports System.Configuration
Imports System.Data.SqlClient
Partial Class traininfo
    Inherits System.Web.UI.Page
    Dim dat As Date

    Protected Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        Dim rowIndex As Integer = Convert.ToInt32(e.CommandArgument)
        Dim row As GridViewRow = GridView1.Rows(rowIndex)
        If e.CommandName.Equals("Submita") Then
            Session("dat1") = Me.Label1.Text
            Session("tra1") = "3A AC"
            Session("train1") = row.Cells(0).Text
            Session("train2") = row.Cells(1).Text
            Session("train3") = row.Cells(2).Text
            Session("train4") = row.Cells(4).Text
            Response.Redirect("checkab.aspx")
        ElseIf e.CommandName.Equals("Submits") Then
            Session("dat1") = Me.Label1.Text
            Session("tra1") = "Sleeper Class"
            Session("train1") = row.Cells(0).Text
            Session("train2") = row.Cells(1).Text
            Session("train3") = row.Cells(2).Text
            Session("train4") = row.Cells(4).Text
            Response.Redirect("checkab.aspx")
        End If


    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim lb = New LinkButton

    End Sub

    
    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        'If Me.GridView1.SelectedRow.Cells(7).ToString = "System.Web.UI.WebControls.DataControlFieldCell" Then
        'Session("tra1") = "3A"
        'Session("tra2") = Me.GridView1.SelectedRow.Cells(1).Text
        'Response.Redirect("checkab.aspx")
        'ElseIf Me.GridView1.SelectedRow.Cells(9).ToString = "System.Web.UI.WebControls.DataControlFieldCell" Then

        'Session("tra3") = "SL"
        'Session("tra4") = Me.GridView1.SelectedRow.Cells(1).ToString
        'Response.Redirect("checkab.aspx")
        'End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Me.Label1.Text = Session("dat")
        End If
    End Sub

    Protected Sub Back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Back.Click
        Response.Redirect("checkbook.aspx")
    End Sub
End Class
