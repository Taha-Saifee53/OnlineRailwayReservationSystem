
Partial Class seatavail
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim i, cnt As Integer
    Dim curr, pre As Date

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.Label3.Text = Session("we")
        If Not IsPostBack Then
            curr = DateTime.Today.ToString
            Me.Label1.Text = curr
            pre = DateTime.Today.AddMonths(4)
            Me.Label2.Text = pre
        End If
    End Sub

    Protected Sub se_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles se.Click
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select * from traindet"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        For i = 0 To cnt - 1
            If Me.trainn.Text = ob.ds.Tables("lg").Rows(i)(1) And Me.st.Text = ob.ds.Tables("lg").Rows(i)(2) And Me.jd.Text <> "" And Me.cla.Text <> "Select" And Me.dt.Text = ob.ds.Tables("lg").Rows(i)(3) And Me.Label1.Text < Me.jd.Text And Me.Label2.Text > Me.jd.Text And Me.st.Text <> Me.dt.Text Then
                Session("no") = Me.trainn.Text
                Session("date") = Me.jd.Text
                Session("we") = Me.Label3.Text
                Response.Redirect("seatenquiry.aspx")
            End If
        Next
        Me.err.Visible = True
    End Sub

    Protected Sub cle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cle.Click
        If Me.Label3.Text = "" Then
            Response.Redirect("welcome.aspx")
        Else
            Response.Redirect("welcome1.aspx")
        End If

    End Sub
End Class
