
Partial Class displayhistory
    Inherits System.Web.UI.Page

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Session("pnn") = Me.GridView1.SelectedRow.Cells(2).Text
        Session("od") = Me.GridView1.SelectedRow.Cells(1).Text
        Session("amt") = Me.GridView1.SelectedRow.Cells(3).Text
        Response.Redirect("genticket.aspx")

    End Sub

   Protected Sub Back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Back.Click
        Response.Redirect("bookinghistory.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
