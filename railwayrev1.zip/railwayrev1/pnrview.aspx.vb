

Partial Class pnrview
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim cnt, cnt1, i As Integer
    Dim pn As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        pn = Session("pnrs")
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from booking"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "gr1")
        cnt = ob.ds.Tables("gr1").Rows.Count
        For i = 0 To cnt - 1
            If pn = ob.ds.Tables("gr1").Rows(i)(0) Then
                ob.cmd.CommandText = "select *from booking where pnr='" & pn & "'"
                ob.adp.SelectCommand = ob.cmd
                ob.adp.Fill(ob.ds, "gt")
                cnt1 = ob.ds.Tables("gt").Rows.Count
                Me.p.Text = cnt
                Me.pno.Text = ob.ds.Tables("gr1").Rows(i)(0)
                Me.da.Text = ob.ds.Tables("gr1").Rows(i)(12)
                Me.tran.Text = ob.ds.Tables("gr1").Rows(i)(9)
                Me.fs.Text = ob.ds.Tables("gr1").Rows(i)(10)
                Me.ts.Text = ob.ds.Tables("gr1").Rows(i)(11)
                Me.rs.Text = ob.ds.Tables("gr1").Rows(i)(15)
                Me.cl.Text = ob.ds.Tables("gr1").Rows(i)(13)
                Me.bp.Text = ob.ds.Tables("gr1").Rows(i)(14)
            End If
        Next

    End Sub

    Protected Sub Submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Submit.Click
        Response.Redirect("pnrstatus.aspx")
    End Sub
End Class
