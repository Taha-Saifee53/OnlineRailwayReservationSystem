
Partial Class genticket
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim cnt, cnt1, i, j As Integer
    Dim amt1 As String
    Dim time, time1 As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.pnr.Text = Session("pnn")
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from booking"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "bk")
        cnt = ob.ds.Tables("bk").Rows.Count
        
        For i = 0 To cnt - 1
            If Me.pnr.Text = ob.ds.Tables("bk").Rows(i)(0) Then
                Me.trn.Text = ob.ds.Tables("bk").Rows(i)(9)
                Me.dt.Text = ob.ds.Tables("bk").Rows(i)(12)
                Me.fs.Text = ob.ds.Tables("bk").Rows(i)(10)
                Me.ts.Text = ob.ds.Tables("bk").Rows(i)(11)
                Me.bs.Text = ob.ds.Tables("bk").Rows(i)(14)
                Me.rs.Text = ob.ds.Tables("bk").Rows(i)(15)
                Me.cl.Text = ob.ds.Tables("bk").Rows(i)(13)
                Me.tid.Text = Session("od")
                Me.amt.Text = Session("amt")
            End If
        Next

        

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("welcome1.aspx")
    End Sub
End Class
