
Partial Class booking
    Inherits System.Web.UI.Page
    Dim ob As New Class1
    Dim flag, gend, berth, pnr, seat, co, be, tclass, age, gen, sta As String
    Dim cnt, i, bs, amt, cnts, cntsta, j As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.trainno.Text = Session("tr1") & "/" & Session("tr2")
        Me.station.Text = Session("tr3")
        Me.tstation.Text = Session("tr4")
        Me.trj.Text = Session("dat")

        Me.rstation.Text = Session("tr4")
        Me.clas.Text = Session("cla")
        Me.quota.Text = "General"
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from traindet where tnum='" & Session("tr1") & "'"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg1")
        cntsta = ob.ds.Tables("lg1").Rows.Count
        For j = 0 To cntsta - 1
            Me.bstation.Items.Add(ob.ds.Tables("lg1").Rows(j)(2))
            Me.bstation.Items.Add(ob.ds.Tables("lg1").Rows(j)(9))
            Me.bstation.Items.Add(ob.ds.Tables("lg1").Rows(j)(10))
            Me.bstation.Items.Add(ob.ds.Tables("lg1").Rows(j)(11))
            Me.bstation.Items.Add(ob.ds.Tables("lg1").Rows(j)(12))
            Me.bstation.Items.Add(ob.ds.Tables("lg1").Rows(j)(13))
        Next
    End Sub

    Protected Sub su_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles su.Click

        ob.con.Open()
        ob.cmd.Connection = ob.con
        ob.cmd.CommandText = "select *from booking"
        ob.adp.SelectCommand = ob.cmd
        ob.adp.Fill(ob.ds, "lg")
        cnt = ob.ds.Tables("lg").Rows.Count
        pnr = "65925678" & cnt + 1
        tclass = Me.clas.Text
        sta = Me.bstation.SelectedItem.ToString
        If Me.clas.Text = "Sleeper Class" Then
            If Me.p1.Text <> "" Then                                                         'insert first passenger
                If Me.b1.SelectedItem.Value = "0" Then
                    gend = Me.gen1.SelectedItem.ToString
                    amt = 750
                    If Me.s1.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "ta")
                    bs = ob.ds.Tables("ta").Rows.Count
                    co = ob.ds.Tables("ta").Rows(0)(0)
                    seat = ob.ds.Tables("ta").Rows(0)(1)
                    be = ob.ds.Tables("ta").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p1.Text & "','" & Me.a1.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen1.SelectedItem.ToString
                    amt = 750
                    If Me.s1.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "ja")
                    cnts = ob.ds.Tables("ja").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b1.SelectedItem.ToString = ob.ds.Tables("ja").Rows(i)(2) Then
                            co = ob.ds.Tables("ja").Rows(i)(0)
                            seat = ob.ds.Tables("ja").Rows(i)(1)
                            be = ob.ds.Tables("ja").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p1.Text & "','" & Me.a1.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p2.Text <> "" Then                                                                 'insert second passenger
                If Me.b2.SelectedItem.ToString = "Select" Then
                    gend = Me.gen2.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s2.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "dd")
                    bs = ob.ds.Tables("dd").Rows.Count
                    co = ob.ds.Tables("dd").Rows(0)(0)
                    seat = ob.ds.Tables("dd").Rows(0)(1)
                    be = ob.ds.Tables("dd").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p2.Text & "','" & Me.a2.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen2.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s2.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "j")
                    cnts = ob.ds.Tables("j").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b2.SelectedItem.ToString = ob.ds.Tables("j").Rows(i)(2) Then
                            co = ob.ds.Tables("j").Rows(i)(0)
                            seat = ob.ds.Tables("j").Rows(i)(1)
                            be = ob.ds.Tables("j").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p2.Text & "','" & Me.a2.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p3.Text <> "" Then                                                    'insert third passenger
                If Me.b3.SelectedItem.ToString = "Select" Then
                    gend = Me.gen3.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s3.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "t")
                    bs = ob.ds.Tables("t").Rows.Count
                    co = ob.ds.Tables("t").Rows(0)(0)
                    seat = ob.ds.Tables("t").Rows(0)(1)
                    be = ob.ds.Tables("t").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p3.Text & "','" & Me.a3.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen3.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s3.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jay")
                    cnts = ob.ds.Tables("jay").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b3.SelectedItem.ToString = ob.ds.Tables("jay").Rows(i)(2) Then
                            co = ob.ds.Tables("jay").Rows(i)(0)
                            seat = ob.ds.Tables("jay").Rows(i)(1)
                            be = ob.ds.Tables("jay").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p3.Text & "','" & Me.a3.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p4.Text <> "" Then                                                         'insert fourth passenger
                If Me.b4.SelectedItem.ToString = "Select" Then
                    gend = Me.gen4.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s4.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "tah")
                    bs = ob.ds.Tables("tah").Rows.Count
                    co = ob.ds.Tables("tah").Rows(0)(0)
                    seat = ob.ds.Tables("tah").Rows(0)(1)
                    be = ob.ds.Tables("tah").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p4.Text & "','" & Me.a4.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen4.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s4.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jaa")
                    cnts = ob.ds.Tables("jaa").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b4.SelectedItem.ToString = ob.ds.Tables("jaa").Rows(i)(2) Then
                            co = ob.ds.Tables("jaa").Rows(i)(0)
                            seat = ob.ds.Tables("jaa").Rows(i)(1)
                            be = ob.ds.Tables("jaa").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p4.Text & "','" & Me.a4.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p5.Text <> "" Then                                                        'insert fifth passenger
                If Me.b5.SelectedItem.ToString = "Select" Then
                    gend = Me.gen5.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s5.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "taha")
                    bs = ob.ds.Tables("taha").Rows.Count
                    co = ob.ds.Tables("taha").Rows(0)(0)
                    seat = ob.ds.Tables("taha").Rows(0)(1)
                    be = ob.ds.Tables("taha").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p5.Text & "','" & Me.a5.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen5.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s5.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jaaa")
                    cnts = ob.ds.Tables("jaaa").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b5.SelectedItem.ToString = ob.ds.Tables("jaaa").Rows(i)(2) Then
                            co = ob.ds.Tables("jaaa").Rows(i)(0)
                            seat = ob.ds.Tables("jaaa").Rows(i)(1)
                            be = ob.ds.Tables("jaaa").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p5.Text & "','" & Me.a5.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p6.Text <> "" Then                                                     'insert sixth passenger
                If Me.b6.SelectedItem.ToString = "Select" Then
                    gend = Me.gen6.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s6.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "taaha")
                    bs = ob.ds.Tables("taaha").Rows.Count
                    co = ob.ds.Tables("taaha").Rows(0)(0)
                    seat = ob.ds.Tables("taaha").Rows(0)(1)
                    be = ob.ds.Tables("taaha").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p6.Text & "','" & Me.a6.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen6.SelectedItem.ToString
                    amt = amt + 750
                    If Me.s6.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seat"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jat")
                    cnts = ob.ds.Tables("jat").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b6.SelectedItem.ToString = ob.ds.Tables("jat").Rows(i)(2) Then
                            co = ob.ds.Tables("jat").Rows(i)(0)
                            seat = ob.ds.Tables("jat").Rows(i)(1)
                            be = ob.ds.Tables("jat").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p6.Text & "','" & Me.a6.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seat where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If
        Else
            If Me.p1.Text <> "" Then                                                         'insert first passenger
                If Me.b1.SelectedItem.Value = "0" Then
                    gend = Me.gen1.SelectedItem.ToString
                    amt = 1500
                    If Me.s1.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "ta")
                    bs = ob.ds.Tables("ta").Rows.Count
                    co = ob.ds.Tables("ta").Rows(0)(0)
                    seat = ob.ds.Tables("ta").Rows(0)(1)
                    be = ob.ds.Tables("ta").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p1.Text & "','" & Me.a1.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen1.SelectedItem.ToString
                    amt = 1500
                    If Me.s1.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "ja")
                    cnts = ob.ds.Tables("ja").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b1.SelectedItem.ToString = ob.ds.Tables("ja").Rows(i)(2) Then
                            co = ob.ds.Tables("ja").Rows(i)(0)
                            seat = ob.ds.Tables("ja").Rows(i)(1)
                            be = ob.ds.Tables("ja").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p1.Text & "','" & Me.a1.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p2.Text <> "" Then                                                                 'insert second passenger
                If Me.b2.SelectedItem.ToString = "Select" Then
                    gend = Me.gen2.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s2.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "dd")
                    bs = ob.ds.Tables("dd").Rows.Count
                    co = ob.ds.Tables("dd").Rows(0)(0)
                    seat = ob.ds.Tables("dd").Rows(0)(1)
                    be = ob.ds.Tables("dd").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p2.Text & "','" & Me.a2.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen2.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s2.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "j")
                    cnts = ob.ds.Tables("j").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b2.SelectedItem.ToString = ob.ds.Tables("j").Rows(i)(2) Then
                            co = ob.ds.Tables("j").Rows(i)(0)
                            seat = ob.ds.Tables("j").Rows(i)(1)
                            be = ob.ds.Tables("j").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p2.Text & "','" & Me.a2.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p3.Text <> "" Then                                                    'insert third passenger
                If Me.b3.SelectedItem.ToString = "Select" Then
                    gend = Me.gen3.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s3.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "t")
                    bs = ob.ds.Tables("t").Rows.Count
                    co = ob.ds.Tables("t").Rows(0)(0)
                    seat = ob.ds.Tables("t").Rows(0)(1)
                    be = ob.ds.Tables("t").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p3.Text & "','" & Me.a3.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen3.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s3.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jay")
                    cnts = ob.ds.Tables("jay").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b3.SelectedItem.ToString = ob.ds.Tables("jay").Rows(i)(2) Then
                            co = ob.ds.Tables("jay").Rows(i)(0)
                            seat = ob.ds.Tables("jay").Rows(i)(1)
                            be = ob.ds.Tables("jay").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p3.Text & "','" & Me.a3.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p4.Text <> "" Then                                                         'insert fourth passenger
                If Me.b4.SelectedItem.ToString = "Select" Then
                    gend = Me.gen4.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s4.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "tah")
                    bs = ob.ds.Tables("tah").Rows.Count
                    co = ob.ds.Tables("tah").Rows(0)(0)
                    seat = ob.ds.Tables("tah").Rows(0)(1)
                    be = ob.ds.Tables("tah").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p4.Text & "','" & Me.a4.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen4.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s4.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jaa")
                    cnts = ob.ds.Tables("jaa").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b4.SelectedItem.ToString = ob.ds.Tables("jaa").Rows(i)(2) Then
                            co = ob.ds.Tables("jaa").Rows(i)(0)
                            seat = ob.ds.Tables("jaa").Rows(i)(1)
                            be = ob.ds.Tables("jaa").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p4.Text & "','" & Me.a4.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p5.Text <> "" Then                                                        'insert fifth passenger
                If Me.b5.SelectedItem.ToString = "Select" Then
                    gend = Me.gen5.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s5.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "taha")
                    bs = ob.ds.Tables("taha").Rows.Count
                    co = ob.ds.Tables("taha").Rows(0)(0)
                    seat = ob.ds.Tables("taha").Rows(0)(1)
                    be = ob.ds.Tables("taha").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p5.Text & "','" & Me.a5.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen5.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s5.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jaaa")
                    cnts = ob.ds.Tables("jaaa").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b5.SelectedItem.ToString = ob.ds.Tables("jaaa").Rows(i)(2) Then
                            co = ob.ds.Tables("jaaa").Rows(i)(0)
                            seat = ob.ds.Tables("jaaa").Rows(i)(1)
                            be = ob.ds.Tables("jaaa").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p5.Text & "','" & Me.a5.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If

            If Me.p6.Text <> "" Then                                                     'insert sixth passenger
                If Me.b6.SelectedItem.ToString = "Select" Then
                    gend = Me.gen6.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s6.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If

                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "taaha")
                    bs = ob.ds.Tables("taaha").Rows.Count
                    co = ob.ds.Tables("taaha").Rows(0)(0)
                    seat = ob.ds.Tables("taaha").Rows(0)(1)
                    be = ob.ds.Tables("taaha").Rows(0)(2)
                    ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p6.Text & "','" & Me.a6.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                    ob.cmd.ExecuteNonQuery()
                    ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                    ob.cmd.ExecuteNonQuery()
                Else
                    gend = Me.gen6.SelectedItem.ToString
                    amt = amt + 1500
                    If Me.s6.Checked = True Then
                        flag = "Yes"
                    Else
                        flag = "No"
                    End If
                    ob.cmd.Connection = ob.con
                    ob.cmd.CommandText = "select *from seata"
                    ob.adp.SelectCommand = ob.cmd
                    ob.adp.Fill(ob.ds, "jat")
                    cnts = ob.ds.Tables("jat").Rows.Count
                    For i = 0 To cnts - 1
                        If Me.b6.SelectedItem.ToString = ob.ds.Tables("jat").Rows(i)(2) Then
                            co = ob.ds.Tables("jat").Rows(i)(0)
                            seat = ob.ds.Tables("jat").Rows(i)(1)
                            be = ob.ds.Tables("jat").Rows(i)(2)
                            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.p6.Text & "','" & Me.a6.Text & "','" & gend & "','" & flag & "','" & be & "','" & amt & "','" & seat & "','" & co & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
                            ob.cmd.ExecuteNonQuery()
                            ob.cmd.CommandText = "delete from seata where seat='" & seat & "'"
                            ob.cmd.ExecuteNonQuery()
                            Exit For
                        End If
                    Next
                End If
            End If
        End If

        If Me.ch1.Text <> "" Then
            age = Me.ca1.SelectedItem.ToString
            gen = Me.cg1.SelectedItem.ToString
            ob.cmd.Connection = ob.con
            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.ch1.Text & "','" & age & "','" & gen & "','" & "" & "','" & "" & "','" & "" & "','" & "" & "','" & "" & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
            ob.cmd.ExecuteNonQuery()

        End If
        If Me.ch2.Text <> "" Then
            age = Me.ca2.SelectedItem.ToString
            gen = Me.cg2.SelectedItem.ToString
            ob.cmd.Connection = ob.con
            ob.cmd.CommandText = "insert into booking values('" & pnr & "','" & Me.ch2.Text & "','" & age & "','" & gen & "','" & "" & "','" & "" & "','" & "" & "','" & "" & "','" & "" & "','" & Me.trainno.Text & "','" & Me.station.Text & "','" & Me.tstation.Text & "','" & Me.trj.Text & "','" & tclass & "','" & sta & "','" & Me.rstation.Text & "')"
            ob.cmd.ExecuteNonQuery()
        End If
        Session("amnt") = amt
        Session("pnrst") = pnr
        Response.Redirect("getw.aspx")
        ob.con.Close()

    End Sub

    

   
    Protected Sub back_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles back.Click
        Response.Redirect("seatbooking.aspx")
    End Sub
End Class

